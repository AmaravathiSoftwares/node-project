import * as masterMdl from '../models/mainMastersModels.js';
import fs from 'fs';

//departmant start

export async function createdepartmentMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createdepartmentMasterMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "created successfully" });
    });
}

export async function getdepartmentMastersCtrl(req, res) {
    const data = req.body;
    masterMdl.getdepartmentMastersMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "data": cRes });
    });
}

export async function updatedepartmentMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updatedepartmentMasterMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "updated successfully" });
    });
}

export async function deletedepartmentMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deletedepartmentMasterMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "deleted successfully" });
    });
}
// start  desginations

export async function createdesginationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createdesginationMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "created successfully" });
    });
}

export async function getdesginationsCtrl(req, res) {
    const data = req.body;
    masterMdl.getdesginationsMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500,"msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "data": cRes });
    });
}

export async function updatedesginationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updatedesginationMdl(data, function (err, cRes) {
        if (err) {
             res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "updated successfully" });
    });
}

export async function deletedesginationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deletedesginationMdl(data, function (err, cRes) {
        if (err) {
             res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "deleted successfully" });
    });
}


//roles start
export async function createRoleCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createRoleMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "Role created successfully" });
    });
}

export async function getRolesCtrl(req, res) {
    var data = req.body; // You can add parameters here if needed
    masterMdl.getRolesMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "data": cRes });
    });
};
export async function updateRoleCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updateRoleMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "Role updated successfully" });
    });
};

export async function deleteRoleCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deleteRoleMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "Role deleted successfully" });
    });
}

// District start
export async function createDistrictCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createDistrictMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "District created successfully" });
    });
}

export async function getDistrictsCtrl(req, res) {
    var data = req.body;
    masterMdl.getDistrictsMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "data": cRes });
    });
}

export async function updateDistrictCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updateDistrictMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "District updated successfully" });
    });
}

export async function deleteDistrictCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deleteDistrictMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "District deleted successfully" });
    });
}

//Ulb start
export async function createUlbCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createUlbMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "ULB created successfully" });
    });
}
export async function getUlbsCtrl(req, res) {
    var data = req.body;
    masterMdl.getUlbsMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "data": cRes });
    });
}
export async function updateUlbCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updateUlbMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "ULB updated successfully" });
    });
}
export async function deleteUlbCtrl(req, res) {
    var data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deleteUlbMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "ULB deleted successfully" });
    });
}

//mandal lsit start


export async function geDistrictWiseMandalsdataCtrl(req, res) {
    var data = req.body;
    masterMdl.geDistrictWiseMandalsdataMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "data": cRes });
    });
}

export async function createmandalListCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createmandalListMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "msg": "mandal_list created successfully" });
    });
}

export async function getmandalListsCtrl(req, res) {
    const data = req.body;
    masterMdl.getmandalListsMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ "status": 200, "data": cRes });
    });
}

export async function updatemandalListCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updatemandalListMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "mandal_list updated successfully" });
    });
}

export async function deletemandalListCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deletemandalListMdl(data, function (err, cRes) {
        if (err) {
            res.send({ "status": 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "mandal_list deleted successfully" });
    });
}

//templeRegistration start


export async function geMandalWiseVillagesdataCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.geMandalWiseVillagesdatamDl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, data: cRes });
    });
}

export async function createtempleRegistrationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createtempleRegistrationMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "created successfully" });
    });
}

export async function gettempleRegistrationsCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    masterMdl.gettempleRegistrationsMdl(data,user, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "data": cRes });
    });
}

export async function updatetempleRegistrationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updatetempleRegistrationMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "updated successfully" });
    });
}

export async function deletetempleRegistrationCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deletetempleRegistrationMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "deleted successfully" });
    });
}
// categories

export async function createcategoryMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.createcategoryMasterMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "created successfully" });
    });
}

export async function getcategoryMastersCtrl(req, res) {
    const data = req.body;
    masterMdl.getcategoryMastersMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500,"msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "data": cRes });
    });
}

export async function updatecategoryMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.updated_by = user.id;
    masterMdl.updatecategoryMasterMdl(data, function (err, cRes) {
        if (err) {
             res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "updated successfully" });
    });
}

export async function deletecategoryMasterCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.d_by = user.id;
    masterMdl.deletecategoryMasterMdl(data, function (err, cRes) {
        if (err) {
             res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, "msg": "deleted successfully" });
    });
}

export async function geVillageWiseTemplesdataCtrl(req, res) {
    const data = req.body;
    let user = req.user;
    data.entry_by = user.id;
    masterMdl.geVillageWiseTemplesdataMdl(data, function (err, cRes) {
        if (err) {
            res.send({ status: 500, "msg": "Server Error" });
            return;
        }
        res.send({ status: 200, data: cRes });
    });
}
