import { Router } from 'express';
const router = Router();
import * as ctrl from "../controls/mainMastersCtrl.js";
import { validateJWT } from "../../../utils/jwtUtils.js";
import { mMValidator, checkValidation } from "../validators/mainMastervalidators.js"

// strat departmnet
router.post('/createdepartmentMaster', validateJWT, mMValidator.department_masterValidator, checkValidation, ctrl.createdepartmentMasterCtrl);
router.post('/getdepartmentMasters', validateJWT, ctrl.getdepartmentMastersCtrl);
router.post('/updatedepartmentMaster', validateJWT, mMValidator.department_masterValidator, checkValidation, ctrl.updatedepartmentMasterCtrl);
router.post('/deletedepartmentMaster', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deletedepartmentMasterCtrl);
//start desgination
router.post('/createdesgination', validateJWT, mMValidator.desginationValidator, checkValidation, ctrl.createdesginationCtrl);
router.post('/getdesginations', validateJWT, ctrl.getdesginationsCtrl);
router.post('/updatedesgination', validateJWT, mMValidator.desginationValidator, checkValidation, ctrl.updatedesginationCtrl);
router.post('/deletedesgination', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deletedesginationCtrl);

//roles start
router.post('/createRole', validateJWT, mMValidator.createRole, checkValidation, ctrl.createRoleCtrl);
router.post('/getRoles', validateJWT, ctrl.getRolesCtrl);
router.post('/updateRole', validateJWT, mMValidator.createRole, checkValidation, ctrl.updateRoleCtrl);
router.post('/deleteRole', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deleteRoleCtrl);
// District start
router.post('/createDistrict', validateJWT, mMValidator.createDistrict, checkValidation, ctrl.createDistrictCtrl);
router.post('/getDistricts', validateJWT, ctrl.getDistrictsCtrl);
router.post('/updateDistrict', validateJWT, mMValidator.createDistrict, checkValidation, ctrl.updateDistrictCtrl);
router.post('/deleteDistrict', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deleteDistrictCtrl);

//Ulb start
router.post('/createUlb', validateJWT, mMValidator.createUlb, checkValidation, ctrl.createUlbCtrl);
router.post('/getUlbs', validateJWT, ctrl.getUlbsCtrl);
router.post('/updateUlb', validateJWT, mMValidator.createUlb, checkValidation, ctrl.updateUlbCtrl);
router.post('/deleteUlb', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deleteUlbCtrl);

// Mandal list start

router.post('/geDistrictWiseMandalsdata', validateJWT, ctrl.geDistrictWiseMandalsdataCtrl);
router.post('/createmandalList', validateJWT, mMValidator.mandal_listValidator, checkValidation, ctrl.createmandalListCtrl);
router.post('/getmandalLists', validateJWT, ctrl.getmandalListsCtrl);
router.post('/updatemandalList', validateJWT, mMValidator.mandal_listValidator, checkValidation, ctrl.updatemandalListCtrl);
router.post('/deletemandalList', validateJWT, mMValidator.deleteRow, checkValidation, ctrl.deletemandalListCtrl);

//temple Registration
router.post('/geMandalWiseVillagesdata', validateJWT, ctrl.geMandalWiseVillagesdataCtrl);
router.post('/createtempleRegistration', validateJWT, ctrl.createtempleRegistrationCtrl);
router.post('/gettempleRegistrations', validateJWT, ctrl.gettempleRegistrationsCtrl);
router.post('/updatetempleRegistration', validateJWT, ctrl.updatetempleRegistrationCtrl);
router.post('/deletetempleRegistration', validateJWT, ctrl.deletetempleRegistrationCtrl);
//categories
router.post('/createcategoryMaster', validateJWT, mMValidator.category_masterValidator, checkValidation, ctrl.createcategoryMasterCtrl);
router.post('/getcategoryMasters', validateJWT, ctrl.getcategoryMastersCtrl);
router.post('/updatecategoryMaster', validateJWT, mMValidator.category_masterValidator, checkValidation, ctrl.updatecategoryMasterCtrl);
router.post('/deletecategoryMaster', validateJWT,mMValidator.deleteRow, checkValidation, ctrl.deletecategoryMasterCtrl);

router.post('/geVillageWiseTemplesdata', validateJWT, ctrl.geVillageWiseTemplesdataCtrl);



export default router;
