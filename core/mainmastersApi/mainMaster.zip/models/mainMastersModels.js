import { MySQLConPool } from '../../../config/dbconnect.js';
import { sqlinjection } from '../../../utils/utils.js';
import moment from "moment-timezone";


//department start
export function createdepartmentMasterMdl(data, callback) {
    const cntxtDtls = "in createdepartmentMasterMdl";
    const { department_nm, entry_by } = data;
    const QRY_TO_EXEC = `INSERT INTO department_master (department_nm,entry_by) VALUES (?,?) ON DUPLICATE KEY UPDATE entry_by = VALUES(entry_by)`;
    let paramsData = [department_nm, entry_by];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function getdepartmentMastersMdl(data, callback) {
    const cntxtDtls = "in getdepartmentMastersMdl";
    const QRY_TO_EXEC = `SELECT * FROM department_master where d_in=0 order by department_nm`;
    let paramsData = [];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function updatedepartmentMasterMdl(data, callback) {
    const cntxtDtls = "in updatedepartmentMasterMdl";
    const { department_nm, rowId, updated_by } = data;
    const QRY_TO_EXEC = `UPDATE department_master SET department_nm = ?,updated_by=? WHERE id = ?`;
    let paramsData = [department_nm, updated_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function deletedepartmentMasterMdl(data, callback) {
    const cntxtDtls = "in deletedepartmentMasterMdl";
    const { rowId, d_by } = data;
    const QRY_TO_EXEC = `UPDATE department_master  SET d_in = 1,d_by=? WHERE id  = ?`;
    let paramsData = [d_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}
// start  desginations

export function createdesginationMdl(data, callback) {
    const cntxtDtls = "in createdesginationMdl";
    const { dept_id, designation_nm, entry_by } = data;
    const QRY_TO_EXEC = `INSERT INTO desgination_table (dept_id, designation_nm) VALUES (?, ?)`;
    let paramsData = [dept_id, designation_nm, entry_by];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function getdesginationsMdl(data, callback) {
    const cntxtDtls = "in getdesginationsMdl";
    const QRY_TO_EXEC = `SELECT de.*,d.department_nm FROM desgination_table as de 
    join department_master as d on d.id = de.dept_id
    where de.d_in=0 and d.d_in=0`;
    let paramsData = [];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function updatedesginationMdl(data, callback) {
    const cntxtDtls = "in updatedesginationMdl";
    const { dept_id, designation_nm, updated_by, rowId } = data;
    const QRY_TO_EXEC = `UPDATE desgination_table SET dept_id = ?, designation_nm = ?,updated_by=? WHERE id = ?`;
    let paramsData = [dept_id, designation_nm, updated_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function deletedesginationMdl(data, callback) {
    const cntxtDtls = "in deletedesginationMdl";
    const { d_by, rowId } = data;
    const QRY_TO_EXEC = `UPDATE desgination_table  SET d_in = 1,d_by=? WHERE id = ?`;
    let paramsData = [d_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

//roles start
export function createRoleMdl(data, callback) {
    var cntxtDtls = "in createRoleMdl";
    var { role_type, canCreate, canEdit, canDelete, entry_by } = data;
    var QRY_TO_EXEC = `INSERT INTO roles (role_type, canCreate, canEdit, canDelete,entry_by) VALUES (?, ?, ?, ?,?)`;
    let paramsData = [role_type, canCreate, canEdit, canDelete, entry_by];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
};
export function getRolesMdl(data, callback) {
    var cntxtDtls = "in getRolesMdl";
    var QRY_TO_EXEC = `SELECT * FROM roles where d_in=0 and id !='1'`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
};
export function updateRoleMdl(data, callback) {
    var cntxtDtls = "in updateRoleMdl";
    var { role_type, canCreate, canEdit, canDelete, updated_by, rowId } = data;
    var QRY_TO_EXEC = `UPDATE roles SET role_type=?, canCreate = ?, canEdit = ?, canDelete = ?,updated_by=? WHERE id = ?`;
    let paramsData = [role_type, canCreate, canEdit, canDelete, updated_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}
export function deleteRoleMdl(data, callback) {
    var cntxtDtls = "in deleteRoleMdl";
    var { rowId } = data;
    var QRY_TO_EXEC = `UPDATE roles SET d_in=1 WHERE id = ?`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [rowId], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [role_type], cntxtDtls);
    }
}
// District start

export function createDistrictMdl(data, callback) {
    var cntxtDtls = "in createDistrictMdl";
    var { district, entry_by } = data;
    var QRY_TO_EXEC = `INSERT INTO districts_data (district_name, entry_by) VALUES (?, ?)`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [district, entry_by], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}

export function getDistrictsMdl(data, callback) {
    var cntxtDtls = "in getDistrictsMdl";
    var QRY_TO_EXEC = `SELECT * FROM districts_data where d_in=0`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}

export function updateDistrictMdl(data, callback) {
    var cntxtDtls = "in updateDistrictMdl";
    var { rowId, district, updated_by } = data;
    var QRY_TO_EXEC = `UPDATE districts_data SET district_name = ?, updated_by = ? WHERE id = ?`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [district, updated_by, rowId], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}

export function deleteDistrictMdl(data, callback) {
    var cntxtDtls = "in deleteDistrictMdl";
    var { rowId, d_by } = data;
    var QRY_TO_EXEC = `UPDATE districts_data SET d_in = 1 ,d_by=? WHERE id = ?`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [d_by, rowId], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}

//ulb start

export function createUlbMdl(data, callback) {
    var cntxtDtls = "in createUlbMdl";
    var { village_name, district_id, mandal_id, entry_by } = data;
    var QRY_TO_EXEC = `INSERT INTO village_data (village_name, district_id,mandal_id, entry_by) VALUES (?, ?, ?,?)`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [village_name, district_id, mandal_id, entry_by], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [village_name, district_id, entry_by], cntxtDtls);
    }
}
export function getUlbsMdl(data, callback) {
    var cntxtDtls = "in getUlbsMdl";
    var QRY_TO_EXEC = `SELECT d.district_name,m.mandal_name,u.* FROM village_data as u 
    join districts_data as d on d.id = u.district_id
    LEFT JOIN mandal_list as m on m.mandal_id= u.mandal_id
    where u.d_in=0 order by d.district_name,u.village_name`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}
export function updateUlbMdl(data, callback) {
    var cntxtDtls = "in updateUlbMdl";
    var { rowId, village_name, district_id, mandal_id, updated_by } = data;
    var QRY_TO_EXEC = `UPDATE village_data SET village_name = ?, district_id = ?,mandal_id=?, updated_by = ? WHERE village_id   = ?`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [village_name, district_id, mandal_id, updated_by, rowId], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}
export function deleteUlbMdl(data, callback) {
    var cntxtDtls = "in deleteUlbMdl";
    var { rowId, d_by } = data;
    console.log(rowId, 'rowId');

    var QRY_TO_EXEC = `UPDATE village_data SET d_in = 1,d_by=? WHERE village_id  = ?`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [d_by, rowId], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [rowId], cntxtDtls);
    }
}

//Mandal list strat


export function geDistrictWiseMandalsdataMdl(data, callback) {
    var cntxtDtls = "in geDistrictWiseMandalsdataMdl";
    const { district_id } = data;
    var QRY_TO_EXEC = `SELECT * FROM mandal_list  where d_in=0 and district_id =?  order by mandal_name`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [district_id], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}
export function createmandalListMdl(data, callback) {
    const cntxtDtls = "in createmandalListMdl";
    const QRY_TO_EXEC = `INSERT INTO mandal_list (district_id,mandal_name,entry_by) VALUES (?, ?, ?)`;

    let paramsData = [data.district_id, data.mandal_name, data.entry_by];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function getmandalListsMdl(data, callback) {
    const cntxtDtls = "in getmandalListsMdl";
    const QRY_TO_EXEC = `SELECT m.mandal_id,m.mandal_name,m.district_id,d.district_name FROM mandal_list as m 
    join districts_data as d on d.id =m.district_id
    where m.d_in=0 order by d.district_name,m.mandal_name`;

    let paramsData = [];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function updatemandalListMdl(data, callback) {
    const cntxtDtls = "in updatemandalListMdl";
    const { rowId, mandal_name, district_id } = data;
    const QRY_TO_EXEC = `UPDATE mandal_list SET district_id = ?,mandal_name = ? WHERE mandal_id  = ?`;

    let paramsData = [district_id, mandal_name, rowId];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function deletemandalListMdl(data, callback) {
    const cntxtDtls = "in deletemandalListMdl";
    const { rowId } = data;
    const QRY_TO_EXEC = `UPDATE mandal_list SET d_in = 1 WHERE mandal_id  = ?`;

    let paramsData = [rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

// Temple Registration start
export function geMandalWiseVillagesdatamDl(data, callback) {
    var cntxtDtls = "in geMandalWiseVillagesdatamDl";
    const { mandal_id } = data;
    var QRY_TO_EXEC = `SELECT * FROM village_data  where d_in=0 and mandal_id =?  order by village_name`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [mandal_id], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}

export function createtempleRegistrationMdl(data, callback) {
    const cntxtDtls = "in createtempleRegistrationMdl";
    const QRY_TO_EXEC = `INSERT INTO temple_registration (temple_district_id, temple_village_id, temple_mandal_id, temple_name,entry_by,class,
inspector) VALUES (?, ?, ?, ?,?,?,?)`;

    let paramsData = [data.district_id, data.village_id, data.mandal_id, data.temple_name, data.entry_by,data.temple_class,data.inspector];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function gettempleRegistrationsMdl(data, user, callback) {
    const cntxtDtls = "in gettempleRegistrationsMdl";
    console.log(user);
    let whereCondition = ``;
    if (user.role_type == 1) {
        whereCondition = ``;
    } else if (user.role_type == 5) {
        let districts = [];
        if (user.district_id) {
            districts = user.district_id.includes(',') ? user.district_id.split(',').map(w => `'${w.trim()}'`) : [`'${user.district_id.trim()}'`];
        }
        const inClause = districts.join(',');
        whereCondition = `and t.temple_district_id in (${inClause})`;
    } else if (user.role_type == 6) {
        let temples = [];
        if (user.temple_id) {
            temples = user.temple_id.includes(',') ? user.temple_id.split(',').map(w => `'${w.trim()}'`) : [`'${user.temple_id.trim()}'`];
        }
        const inClause = temples.join(',');
        whereCondition = ` and t.temple_id in (${inClause})`;
    } else {
        whereCondition = ``;
    }

    const page = parseInt(data.page) || 1;
    const limit = parseInt(data.pageSize) || 50;
    const offset = (page - 1) * limit;
    const searchText = data.searchText?.trim() || "";
    let paramsData = [];
    let searchParams = [];
    const countQuery = `SELECT COUNT(*) AS total FROM temple_registration t where t.d_in=0 ${whereCondition};`;
    // const QRY_TO_EXEC = `SELECT * FROM temple_registration where d_in=0 ${whereCondition} ORDER BY district_name,mandal_name,village_name,temple_name DESC LIMIT ? OFFSET ?`;
    const QRY_TO_EXEC = `SELECT  t.temple_id,t.temple_district_id,t.temple_mandal_id,t.temple_village_id,t.temple_name,t.tcode,t.class,t.inspector,
    d.district_name,m.mandal_name,v.village_name FROM  temple_registration t
    JOIN  districts_data d ON d.id = t.temple_district_id
    JOIN  mandal_list m ON m.mandal_id = t.temple_mandal_id
    JOIN  village_data v ON v.village_id = t.temple_village_id
    WHERE t.d_in =0  ${whereCondition} ORDER BY d.district_name,m.mandal_name,v.village_name,t.temple_name DESC LIMIT ? OFFSET ?`
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, countQuery, paramsData, cntxtDtls, function (err, countResult) {
            if (err) {
                callback(err);
                return;
            }
            const total = countResult[0]?.total || 0;
            const totalPages = Math.ceil(total / limit);
            sqlinjection(MySQLConPool, QRY_TO_EXEC, [...searchParams, limit, offset], cntxtDtls, function (err, results) {
                if (err) {
                    callback(err);
                    return;
                }
                callback(null, { total: total, totalPages: totalPages, page: page, limit: limit, data: results });
            });
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function updatetempleRegistrationMdl(data, callback) {
    const cntxtDtls = "in updatetempleRegistrationMdl";
    const { district_id, village_id, mandal_id, temple_name, updated_by,temple_class,inspector, rowId } = data;
    const QRY_TO_EXEC = `UPDATE temple_registration SET temple_district_id = ?, temple_village_id = ?, temple_mandal_id = ?, temple_name = ?,updated_by=?,class=?,inspector=? WHERE temple_id  = ?`;

    let paramsData = [district_id, village_id, mandal_id, temple_name, updated_by,temple_class,inspector, rowId];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function deletetempleRegistrationMdl(data, callback) {
    const cntxtDtls = "in deletetempleRegistrationMdl";
    const { rowId, d_by } = data;
    const QRY_TO_EXEC = `UPDATE temple_registration  SET d_in = 1,d_by=? WHERE temple_id = ?`;
    console.log(rowId, 'rowId');

    let paramsData = [d_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}
// categories

export function createcategoryMasterMdl(data, callback) {
    const cntxtDtls = "in createcategoryMasterMdl";
    const { category_nm, category_type, entry_by } = data;
    const QRY_TO_EXEC = `INSERT INTO category_master (category_nm, category_type,entry_by) VALUES (?, ?,?)`;

    let paramsData = [category_nm, category_type, entry_by];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function getcategoryMastersMdl(data, callback) {
    const cntxtDtls = "in getcategoryMastersMdl";
    const QRY_TO_EXEC = `SELECT * FROM category_master where d_in=0`;

    let paramsData = [];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function updatecategoryMasterMdl(data, callback) {
    const cntxtDtls = "in updatecategoryMasterMdl";
    const { category_nm, category_type, updated_by, rowId } = data;
    const QRY_TO_EXEC = `UPDATE category_master SET category_nm = ?, category_type = ?,updated_by=? WHERE id = ?`;

    let paramsData = [category_nm, category_type, updated_by, rowId];

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}

export function deletecategoryMasterMdl(data, callback) {
    const cntxtDtls = "in deletecategoryMasterMdl";
    const { d_by, rowId } = data;
    const QRY_TO_EXEC = `UPDATE category_master  SET d_in = 1,d_by=? WHERE id = ?`;

    let paramsData = [d_by, rowId];
    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, paramsData, cntxtDtls);
    }
}


export function geVillageWiseTemplesdataMdl(data, callback) {
    var cntxtDtls = "in geVillageWiseTemplesdataMdl";
    const { village_id } = data;
    var QRY_TO_EXEC = `SELECT * FROM temple_registration  where d_in=0 and temple_village_id =?  order by temple_name`;

    if (callback && typeof callback == "function") {
        sqlinjection(MySQLConPool, QRY_TO_EXEC, [village_id], cntxtDtls, function (err, results) {
            callback(err, results);
            return;
        });
    } else {
        return sqlinjection(MySQLConPool, QRY_TO_EXEC, [], cntxtDtls);
    }
}
