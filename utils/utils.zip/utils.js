export function sqlinjection(ConPool, Qry, data, cntxtDtls, callback) {

      if (callback && typeof callback == "function") {
            ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                  if (err) { callback(err, null); return err; }
                  // Execute the query
                  connection.query(Qry, data, function (err, rows) {
                        // console.log(err, 'err');
                        // console.log(Qry, 'Queery');
                        // console.log(rows,'rows'); 
                        if (err) {
                              console.log(err)
                        }
                        connection.release();                  // Release connection back to Pool  
                        if (err) { callback(err, null); return; } // Handle Query Errors          
                        callback(false, rows);                 // Send the results back  
                        return;

                  });
            });
      } else {
            return new Promise(function (resolve, reject) {
                  ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                        if (err) {
                              // log.db.conError(cntxtDtls,Qry,err.code,err.fatal); 
                              reject({ "err_status": 500, "err_message": "internel server" });
                        } else {   // Execute the query
                              connection.query(Qry, data, function (err, rows) {
                                    connection.release();                  // Release connection back to Pool  
                                    if (err) {
                                          // log.db.qryError(cntxtDtls,Qry,err.code,err.fatal); 
                                          reject({ "err_status": 500, "err_message": "internal server" });
                                    } // Handle Query Errors 
                                    else {
                                          resolve(rows);                 // Send the results back  
                                    }
                              }); // End of Qry Execuiton
                        }

                  }); // End of get Connection

            }); // End of Promise
      } // End of Else
}
export function execQuery(ConPool, Qry, cntxtDtls, callback) {
      if (callback && typeof callback == "function") {

            ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                  if (err) { console.log(err); callback(err, null); return err; }

                  // Execute the query
                  connection.query(Qry, function (err, rows) {
                        connection.release();                  // Release connection back to Pool  
                        if (err) { console.log(err); callback(true, null); return; } // Handle Query Errors          
                        callback(false, rows);                 // Send the results back  
                        return;
                  });
            });

      } else {
            return new Promise(function (resolve, reject) {
                  ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                        if (err) {
                              // log.db.conError(cntxtDtls,Qry,err.code,err.fatal); 
                              reject({ "err_status": 500, "err_message": "internel server" });
                        } else {   // Execute the query

                              connection.query(Qry, function (err, rows) {
                                    connection.release();                  // Release connection back to Pool  
                                    if (err) {
                                          // log.db.qryError(cntxtDtls,Qry,err.code,err.fatal); 
                                          reject({ "err_status": 500, "err_message": "internal server" });
                                    } // Handle Query Errors 
                                    else {
                                          resolve(rows);                 // Send the results back  
                                    }
                              }); // End of Qry Execuiton
                        }

                  }); // End of get Connection

            }); // End of Promise
      } // End of Else

};

export function execupdateQuery(ConPool, Qry, data, cntxtDtls, callback) {
      // console.log(data);
      if (callback && typeof callback == "function") {
            ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                  if (err) { console.log(err); callback(err, null); return err; }

                  // Execute the query
                  connection.query(Qry, data, function (err, rows) {
                        connection.release();                  // Release connection back to Pool  
                        if (err) { console.log(err); callback(true, null); return; } // Handle Query Errors          
                        callback(false, rows);                 // Send the results back  
                        return;
                  });
            });

      } else {
            return new Promise(function (resolve, reject) {
                  ConPool.getConnection(function (err, connection) {    // get connection from Connection Pool 
                        if (err) {
                              // log.db.conError(cntxtDtls,Qry,err.code,err.fatal); 
                              reject({ "err_status": 500, "err_message": "internel server" });
                        } else {   // Execute the query

                              connection.query(Qry, data, function (err, rows) {
                                    connection.release();                  // Release connection back to Pool  
                                    if (err) {
                                          // log.db.qryError(cntxtDtls,Qry,err.code,err.fatal); 
                                          reject({ "err_status": 500, "err_message": "internal server" });
                                    } // Handle Query Errors 
                                    else {
                                          resolve(rows);                 // Send the results back  
                                    }
                              }); // End of Qry Execuiton
                        }

                  }); // End of get Connection

            }); // End of Promise
      } // End of Else

};